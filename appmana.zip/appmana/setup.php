<?php
/**
 * AppMana — Installateur de base de données
 * ⚠ SUPPRIMER CE FICHIER APRÈS L'INSTALLATION ⚠
 */
require_once __DIR__ . '/config/config.php';

// Protection basique : token dans l'URL
$setupToken = 'CHANGER_CE_TOKEN_AVANT_UTILISATION';
if (($_GET['token'] ?? '') !== $setupToken) {
    http_response_code(403);
    die('403 Forbidden — Ajoutez ?token=CHANGER_CE_TOKEN_AVANT_UTILISATION à l\'URL');
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';charset=' . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Créer la base si elle n'existe pas
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `" . DB_NAME . "`");

    // Lire et exécuter le schéma
    $sql = file_get_contents(__DIR__ . '/database/schema.sql');
    $statements = array_filter(array_map('trim', explode(';', $sql)));

    $ok = 0;
    foreach ($statements as $stmt) {
        if ($stmt) {
            $pdo->exec($stmt);
            $ok++;
        }
    }

    echo "<h2 style='color:green'>✅ Installation réussie !</h2>";
    echo "<p>$ok requêtes exécutées.</p>";
    echo "<p><strong>Compte admin par défaut :</strong> login <code>admin</code> / mot de passe <code>Admin1234!</code></p>";
    echo "<p style='color:red'><strong>⚠ SUPPRIMEZ ce fichier setup.php maintenant !</strong></p>";
    echo "<p><a href='" . APP_URL . "/login.php'>→ Aller à la connexion</a></p>";

} catch (PDOException $e) {
    echo "<h2 style='color:red'>❌ Erreur</h2><pre>" . $e->getMessage() . "</pre>";
}
