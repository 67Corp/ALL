<?php
// ============================================================
// AppMana - Configuration
// NE PAS versionner ce fichier (dans .gitignore)
// Remplir avec vos vraies credentials Infomaniak
// ============================================================

// Base de données
define('DB_HOST', 'localhost');
define('DB_NAME', 'appmana');
define('DB_USER', 'votre_utilisateur_db');
define('DB_PASS', 'votre_mot_de_passe_db');
define('DB_CHARSET', 'utf8mb4');

// Gemini Pro API
define('GEMINI_API_KEY', 'votre_cle_api_gemini');
define('GEMINI_MODEL',   'gemini-pro');
define('GEMINI_API_URL', 'https://generativelanguage.googleapis.com/v1beta/models/' . GEMINI_MODEL . ':generateContent');

// Application
define('APP_NAME', 'AppMana');
define('APP_URL',  'https://votre-domaine.infomaniak.com/appmana');
define('APP_ENV',  'development'); // 'production' en prod

// Session
define('SESSION_NAME',     'appmana_sess');
define('SESSION_LIFETIME', 3600); // 1h

// Uploads
define('UPLOAD_DIR',      __DIR__ . '/../uploads/avatars/');
define('UPLOAD_MAX_SIZE', 5 * 1024 * 1024); // 5 Mo

// Limites API Gemini par utilisateur/heure
define('GEMINI_HOURLY_LIMIT', 20);

// Cache URL (en jours)
define('URL_CACHE_DAYS', 7);
