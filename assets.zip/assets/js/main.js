// Auto-resize du textarea sur la page accueil
const heroInput = document.getElementById('heroInput');
if (heroInput) {
    heroInput.addEventListener('input', () => {
        heroInput.style.height = 'auto';
        heroInput.style.height = heroInput.scrollHeight + 'px';
    });

    // Envoyer avec Entrée (Shift+Entrée pour nouvelle ligne)
    heroInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendQuestion();
        }
    });
}

const heroBtn = document.getElementById('heroBtn');
if (heroBtn) {
    heroBtn.addEventListener('click', sendQuestion);
}

function sendQuestion() {
    const val = heroInput.value.trim();
    if (!val) return;
    // TODO : traiter la question (appel API, redirection, etc.)
    console.log('Question envoyée :', val);
}

// Remplir le champ avec une suggestion
function fillSearch(chip) {
    if (!heroInput) return;
    heroInput.value = chip.textContent;
    heroInput.focus();
    heroInput.style.height = 'auto';
    heroInput.style.height = heroInput.scrollHeight + 'px';
}

// Marquer le lien actif dans la navbar selon la page courante
document.addEventListener('DOMContentLoaded', () => {
    const links = document.querySelectorAll('.navbar-menu a');
    const current = window.location.pathname;
    links.forEach(link => {
        link.classList.remove('active');
        if (current.includes(link.getAttribute('href').replace('../', ''))) {
            link.classList.add('active');
        }
    });
});
